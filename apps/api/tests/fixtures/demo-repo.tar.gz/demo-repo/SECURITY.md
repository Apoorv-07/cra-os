# Security Policy

Report vulnerabilities to security@example.com. We acknowledge reports within
three working days and ship fixes for critical issues within 30 days.
Supported versions: 1.4.x.
