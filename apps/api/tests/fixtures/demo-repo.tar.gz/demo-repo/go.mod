module example.com/demo

go 1.21

require golang.org/x/crypto v0.0.0-20200323165209-0ec3e9974c59
